package banco;

public class Cliente {

    private int cedula;
    private String nombre;
    private String apellido;
    private String genero;
    private int celular;
    private double saldo;

    public Cliente(int cedula, String nombre, String apellido, String genero, int celular, double saldo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.celular = celular;
        this.saldo = saldo;
    }

    public int getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getGenero() {
        return genero;
    }

    public int getCelular() {
        return celular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    @Override
    public String toString() {
        return "Cliente{\n"
                + "\nCedula: " + cedula + "\nNombre: " + nombre + "\nApellido: " + apellido + "\nGenero: " + genero + "\nCelular: " + celular + "\nSaldo: " + saldo+"\n}";
    }
}
