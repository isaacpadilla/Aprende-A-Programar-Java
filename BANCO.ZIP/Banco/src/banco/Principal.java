package banco;

import javax.swing.JOptionPane;

public class Principal {

    static int x = 0;
    static Cliente cli[] = new Cliente[10000000];

    public static void main(String[] args) {
        int op = 0;

        do {

            op = Integer.parseInt(JOptionPane.showInputDialog(null, "Seleccione opcion: \n"
                    + "\n[1]. Ingresar cliente"
                    + "\n[2]. Consultar cliente"
                    + "\n[3]. Modificar cliente"
                    + "\n[4]. Eliminar cuenta"
                    + "\n[5]. Retirar dinero"
                    + "\n[6]. Consignar dinero"
                    + "\n[0]. Salir"));
            switch (op) {
                case 1:
                    int cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cedula del cliente: "));
                    int d = BuscarCliente(cedula);
                    if (d != -1) {
                        JOptionPane.showMessageDialog(null, "El cliente ya existe");
                    } else {
                        String nombre = JOptionPane.showInputDialog(null, "Digite el nombre del cliente: ");
                        String apellido = JOptionPane.showInputDialog(null, "Digite el apellido del cliente: ");
                        String genero = JOptionPane.showInputDialog(null, "Digite el genero del cliente (M/F): ");
                        int celular = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero celular del cliente: "));
                        double dinero = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el monto del Dinero de la cuenta: "));
                        IngresarCliente(cedula, nombre, apellido, genero, celular, dinero);
                        //a traves del metodo IngresarCliente se aumento el tamaño del vector de clientes.
                    }

                    break;
                case 2:

                    cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite Cedula: "));
                    d = BuscarCliente(cedula);
                    if (d == -1) {
                        JOptionPane.showMessageDialog(null, "El cliente no existe");

                    } else {
                        JOptionPane.showMessageDialog(null, cli[d].toString());

                    }

                    break;
                case 3:

                    cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite cedula del cliente a modificar: "));
                    d = BuscarCliente(cedula);
                    if (d == -1) {
                        JOptionPane.showMessageDialog(null, "El cliente no existe");

                    } else {
                        String nombre = JOptionPane.showInputDialog(null, "Digite el nombre del cliente: ");
                        String apellido = JOptionPane.showInputDialog(null, "Digite el apellido del cliente: ");
                        String genero = JOptionPane.showInputDialog(null, "Digite el genero del cliente (M/F): ");
                        int celular = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el numero celular del cliente: "));
                        double dinero = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el monto del Dinero de la cuenta: "));
                        ModificarCliente(cedula, nombre, apellido, genero, celular, dinero, d);
                        JOptionPane.showMessageDialog(null, cli[d].toString());

                    }

                    break;
                case 4:
                    cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite cedula del cliente a Eliminar: "));
                    d = BuscarCliente(cedula);
                    if (d == -1) {
                        JOptionPane.showMessageDialog(null, "El cliente no existe");

                    } else {

                        Cliente temp[] = new Cliente[x];
                        for (int i = 0; i < x; i++) {
                            if (temp[i] != cli[d]) {
                                temp[i] = cli[d];

                            }

                        }
                        x = x - 1;
                        for (int i = 0; i < x; i++) {
                            cli[d] = temp[i];

                        }
                        JOptionPane.showMessageDialog(null, "Cliente eliminado");

                    }

                    break;
                case 5:
                    cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite cedula del cliente a Retirar dinero: "));
                    d = BuscarCliente(cedula);
                    if (d == -1) {
                        JOptionPane.showMessageDialog(null, "El cliente no existe");

                    } else {
                        double saldo = 0;
                        double res = 0;
                        double retiro = 0;
                        if (cli[d].getSaldo() > 0) {
                            JOptionPane.showMessageDialog(null, "Puede Retirar un maximo de: " + cli[d].getSaldo() + " COP");

                            saldo = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el saldo a retirar: "));
                            if (saldo <= cli[d].getSaldo()) {
                                res = cli[d].getSaldo();
                                retiro = res - saldo;
                                cli[d].setSaldo(retiro);
                                JOptionPane.showMessageDialog(null, "Retiro realizado con exito ");

                            } else {
                                JOptionPane.showMessageDialog(null, "Fondos insuficientes ");

                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede retirar, cuenta sin fondos");
                        }
                    }

                    //"\n[5]. Retirar dinero"
                    break;
                case 6:
                    cedula = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite cedula del cliente a Consignar dinero: "));
                    d = BuscarCliente(cedula);
                    if (d == -1) {
                        JOptionPane.showMessageDialog(null, "El cliente no existe");

                    } else {
                        double saldo = 0;
                        double res = 0;
                        double retiro = 0;

                        saldo = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el saldo a consignar: "));

                        res = cli[d].getSaldo();
                        retiro = res + saldo;
                        cli[d].setSaldo(retiro);
                        JOptionPane.showMessageDialog(null, "Consignación realizada con exito ");

                    }

                    break;

            }

        } while (op
                != 0);
    }

    private static void ModificarCliente(int cedula, String nombre, String apellido, String genero, int celular, double dinero, int d) {
        cli[d] = new Cliente(cedula, nombre, apellido, genero, celular, dinero);
        JOptionPane.showMessageDialog(null, "¡Cliente Modificado!");

    }

    private static void IngresarCliente(int cedula, String nombre, String apellido, String genero, int celular, double dinero) {

        cli[x] = new Cliente(cedula, nombre, apellido, genero, celular, dinero);
        JOptionPane.showMessageDialog(null, "¡Cliente creado!");

        x = x + 1;

    }

    private static int BuscarCliente(int cedula) {
        for (int i = 0; i < x; i++) {
            if (cli[i].getCedula() == cedula) {
                return i;
            }
        }
        return -1;
    }

}
