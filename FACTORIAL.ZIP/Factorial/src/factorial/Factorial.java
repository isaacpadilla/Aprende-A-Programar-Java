/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package factorial;

import javax.swing.JOptionPane;

/**
 *
 * @author isaac
 */
public class Factorial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el factorial"));
        Recursividad x = new Recursividad();
        int fac = x.Factorial(num);
        JOptionPane.showMessageDialog(null, "El factorial de: " + num + " es: " + fac);

    }

}
