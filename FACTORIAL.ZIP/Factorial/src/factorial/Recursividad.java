package factorial;

public class Recursividad {

    public int Factorial(int parametro) {
        if (parametro > 0) {
            int vc = parametro * Factorial(parametro - 1);
            return vc;

        }

        return 1;

    }

}
